<?php
class Padre_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }

        public function get_alumno($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                
		                return "";
		        }

		        $query = $this->db->get_where('alumno', array('idAlumno' => $id));
		        return $query->row_array();
		}

		public function get_padre($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                $query = $this->db->get('padre');
		                return $query->result_array();
		        }

		        $query = $this->db->get_where('padre', array('Alumno_idAlumno' => $id));
		        return $query->row_array();
		}

		public function post_padre($padre)
		{
		        $this->db->set( $this->_setPadre($padre) )->insert("padre");

		        if($this->db->affected_rows()===1)
		        {
		        	return TRUE;
		        }

		        return NULL;
		}

		public function put_padre($padre)
		{
		        $this->db->set( $this->_setPadre($padre) )->where('Alumno_idAlumno',$id)->update("padre");

		        if($this->db->affected_rows()===1)
		        {
		        	return $this->db->update_id();
		        }

		        return NULL;
		}

		public function _setPadre($padre)
		{
			$data1 = array(

		        'idPadre' => $padre["idPadre"],
		        'nombre' => $padre["nombre"],
		        'email' => $padre["email"],
		        'apellidos' => $padre["apellidos"],
		        'user' => $padre["user"],
		        'password' => $padre["password"],
		        'telefono' => $padre["telefono"],
		        'dni' => $padre["dni"],
		        'Alumno_idAlumno' => $padre["Alumno_idAlumno"]
	        
	        );

	        return $data1;
		}

}


?>