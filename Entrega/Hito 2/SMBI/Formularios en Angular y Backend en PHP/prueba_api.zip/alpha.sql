-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 29-01-2017 a las 12:31:52
-- Versión del servidor: 10.1.19-MariaDB
-- Versión de PHP: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `alpha`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administrador`
--

CREATE TABLE `administrador` (
  `idAdministrador` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `user` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `dni` varchar(10) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `administrador`
--

INSERT INTO `administrador` (`idAdministrador`, `nombre`, `apellidos`, `user`, `password`, `email`, `telefono`, `dni`) VALUES
(1, 'Manuel', 'Romero Martínez', 'manrom', '1234', 'mrm92@alu.ua.es', 666666666, ''),
(2, 'Ricardo', 'Espinosa Soriano', 'richiesp', '1234', 'res15@alu.ua.es', 666666666, ''),
(3, 'Antonio', 'Martínez Galvañ', 'antonio', '1234', 'amg259@alu.ua.es', 666666666, ''),
(4, 'Jorge', 'Cabanes Pastor', 'georgedelajungla', '1234', 'jcp16@alu.ua.es', 666666666, ''),
(5, 'Nahiara', 'Latorre Gómez', 'nahis19', '1234', 'nlg22@alu.ua.es', 666666666, ''),
(6, 'Juan', 'Sánchez Almendro', 'juansan', '1234', 'juansan@alu.ua.es', 966666666, '56475647O');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE `alumno` (
  `idAlumno` int(11) NOT NULL,
  `InformeAlumno_numExpediente` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `user` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL,
  `dni` varchar(20) DEFAULT NULL,
  `curso_idCurso` int(11) NOT NULL,
  `curso_centro_idCentro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`idAlumno`, `InformeAlumno_numExpediente`, `nombre`, `apellidos`, `user`, `password`, `email`, `telefono`, `dni`, `curso_idCurso`, `curso_centro_idCentro`) VALUES
(1, 1, 'Ruttinger', 'Summers', '101summers', '1234', 'summers101@alu.ua.es', 666666666, NULL, 1, 1),
(2, 2, 'Zacarías', 'Piñedo Valderrama', '102zacary', '1234', 'zpv2@alu.ua.es', NULL, NULL, 1, 1),
(3, 3, 'Isabel María', 'Botías Torres', '103isamari', '1234', 'imbt3@alu.ua.es', NULL, NULL, 1, 1),
(4, 4, 'Priscila', 'Ríos de Luca', '104pris', '1234', 'prdl4@alu.ua.es', NULL, NULL, 1, 1),
(5, 5, 'Gema', 'Sánchez Núñez', '105gsn', '1234', 'gmsn5@alu.ua.es', NULL, NULL, 1, 1),
(6, 6, 'Brayan', 'Bolívar Guevara', '106bbg', '1234', 'bbg6@alu.ua.es', NULL, NULL, 1, 1),
(7, 7, 'Jesús', 'Martínez Ramos', '107jmr', '1234', 'jmr@alu.ua.es', NULL, NULL, 1, 1),
(8, 8, 'Manuel', 'García Quesada', '108mgq', '1234', 'mgq8@alu.ua.es', NULL, NULL, 1, 1),
(9, 9, 'Héctor', 'Gallego Moreno', '109hgm', '1234', 'hgm9@alu.ua.es', NULL, NULL, 1, 1),
(10, 10, 'Abelino', NULL, '', '', NULL, NULL, NULL, 1, 1),
(11, 11, 'Pacharán', 'Garmendia Salmorejo', 'pachirisu', '1234', 'pachirisu@jojo.com', 987654321, '88888888P', 1, 1),
(12, 12, 'Patxi', 'Goicoetxea Zarratrústegui', 'aivalaostiapatxi', '1234', 'patxi@euskadi.com', 654654654, '65465465P', 1, 1),
(13, 13, 'Mariquita', 'Pérez', 'deathmetal45', '1234', 'mariquita@metal.com', 222222222, '21212121O', 1, 1),
(14, 14, 'Ash', 'Ketchum', 'llegareaserelmejor', '1234', 'akdpp@oak.com', 222222222, '55555555I', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura`
--

CREATE TABLE `asignatura` (
  `idAsignatura` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `curso` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `asignatura`
--

INSERT INTO `asignatura` (`idAsignatura`, `nombre`, `curso`) VALUES
(1, 'Conocimiento del medio', 'Primero'),
(2, 'Matemáticas', 'Primero'),
(3, 'Lengua', 'Primero'),
(4, 'Plástica', 'Primero'),
(5, 'Educación física', 'Primero'),
(6, 'Inglés', 'Primero'),
(7, 'Informática', 'Primero'),
(8, 'Tutoría', 'primero');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura_has_curso`
--

CREATE TABLE `asignatura_has_curso` (
  `Asignatura_idAsignatura` int(11) NOT NULL,
  `Curso_idCurso` int(11) NOT NULL,
  `Profesor_idProfesor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `asignatura_has_curso`
--

INSERT INTO `asignatura_has_curso` (`Asignatura_idAsignatura`, `Curso_idCurso`, `Profesor_idProfesor`) VALUES
(1, 1, 1),
(8, 1, 1),
(2, 1, 2),
(3, 1, 3),
(4, 1, 4),
(5, 1, 5),
(6, 1, 6),
(7, 1, 7);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asignatura_has_curso_has_alumno`
--

CREATE TABLE `asignatura_has_curso_has_alumno` (
  `idAsignatura` int(11) NOT NULL,
  `idCurso` int(11) NOT NULL,
  `idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `asignatura_has_curso_has_alumno`
--

INSERT INTO `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) VALUES
(1, 1, 1),
(1, 1, 2),
(1, 1, 3),
(1, 1, 4),
(1, 1, 5),
(1, 1, 6),
(1, 1, 7),
(2, 1, 1),
(2, 1, 2),
(2, 1, 3),
(3, 1, 1),
(3, 1, 2),
(3, 1, 3);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asistencia`
--

CREATE TABLE `asistencia` (
  `idAsistencia` int(11) NOT NULL,
  `falta` tinyint(1) DEFAULT NULL,
  `fecha` datetime NOT NULL,
  `descripcion` varchar(45) DEFAULT NULL,
  `Asignatura_has_Curso_has_Alumno_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idCurso` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `asistencia`
--

INSERT INTO `asistencia` (`idAsistencia`, `falta`, `fecha`, `descripcion`, `Asignatura_has_Curso_has_Alumno_idAsignatura`, `Asignatura_has_Curso_has_Alumno_idCurso`, `Asignatura_has_Curso_has_Alumno_idAlumno`) VALUES
(1, 0, '2016-12-09 01:03:58', 'No ha faltado a clase :)', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `centro`
--

CREATE TABLE `centro` (
  `idCentro` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `TipoCentro_tipo` varchar(45) NOT NULL,
  `Administrador_idAdministrador` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `centro`
--

INSERT INTO `centro` (`idCentro`, `nombre`, `direccion`, `TipoCentro_tipo`, `Administrador_idAdministrador`) VALUES
(1, 'Vasco Núñez de Balboa', 'Avenida de Galileo 13', '1', 1),
(2, 'Bautista Lledó', 'Calle Salazar Gallardo 45', '1', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `chat`
--

CREATE TABLE `chat` (
  `Profesor_idProfesor` int(11) NOT NULL,
  `Padre_Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentarios_sobre_el_alumno`
--

CREATE TABLE `comentarios_sobre_el_alumno` (
  `idComentarios_sobre_el_alumno` int(11) NOT NULL,
  `titulo` varchar(45) DEFAULT NULL,
  `texto` mediumtext NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idCurso` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comentarios_sobre_el_alumno`
--

INSERT INTO `comentarios_sobre_el_alumno` (`idComentarios_sobre_el_alumno`, `titulo`, `texto`, `Asignatura_has_Curso_has_Alumno_idAsignatura`, `Asignatura_has_Curso_has_Alumno_idCurso`, `Asignatura_has_Curso_has_Alumno_idAlumno`) VALUES
(1, 'Comportamiento poco apropiado', 'Don Summers ha demostrado en los últimos días un desdén indeseable que perturba el clima de la asignatura', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario_alumno`
--

CREATE TABLE `comentario_alumno` (
  `idComentario` int(11) NOT NULL,
  `texto` varchar(45) NOT NULL,
  `Foro_idForo` int(11) NOT NULL,
  `Alumno_idAlumno` int(11) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comentario_alumno`
--

INSERT INTO `comentario_alumno` (`idComentario`, `texto`, `Foro_idForo`, `Alumno_idAlumno`, `fecha`) VALUES
(1, 'No me entero de este tema xD', 1, 1, '2016-12-08 19:07:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comentario_profesor`
--

CREATE TABLE `comentario_profesor` (
  `idComentario` int(11) NOT NULL,
  `texto` varchar(45) NOT NULL,
  `Foro_idForo` int(11) NOT NULL,
  `Profesor_idProfesor` int(11) NOT NULL,
  `fecha` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comentario_profesor`
--

INSERT INTO `comentario_profesor` (`idComentario`, `texto`, `Foro_idForo`, `Profesor_idProfesor`, `fecha`) VALUES
(1, 'Pues a estudiar se ha dicho :)', 1, 1, '2016-12-08 19:12:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `comunicado`
--

CREATE TABLE `comunicado` (
  `idcomunicado` int(11) NOT NULL,
  `tipo` varchar(45) DEFAULT NULL,
  `texto` longtext,
  `firmado` varchar(45) DEFAULT NULL,
  `Asignatura_has_Curso_Asignatura_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_Curso_idCurso` int(11) NOT NULL,
  `Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `comunicado`
--

INSERT INTO `comunicado` (`idcomunicado`, `tipo`, `texto`, `firmado`, `Asignatura_has_Curso_Asignatura_idAsignatura`, `Asignatura_has_Curso_Curso_idCurso`, `Alumno_idAlumno`) VALUES
(1, 'Reunión', 'Se convoca a los padres de los alumnos de Primero A a una reunión en el salón de actos mañana', 'false', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curso`
--

CREATE TABLE `curso` (
  `idCurso` int(11) NOT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `grupo` varchar(45) DEFAULT NULL,
  `Profesor_idProfesor` int(11) NOT NULL,
  `centro_idCentro` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `curso`
--

INSERT INTO `curso` (`idCurso`, `nombre`, `grupo`, `Profesor_idProfesor`, `centro_idCentro`) VALUES
(1, 'Primero', 'A', 1, 1),
(2, 'Primero', 'B', 2, 1),
(3, 'Segundo', 'A', 3, 1),
(4, 'Segundo', 'B', 4, 1),
(5, 'Tercero', 'A', 5, 1),
(6, 'Tercero', 'B', 6, 1),
(7, 'Cuarto', 'A', 7, 1),
(8, 'Cuarto', 'B', 8, 1),
(9, 'Quinto', 'A', 9, 1),
(10, 'Quinto', 'B', 10, 1),
(11, 'Sexto', 'A', 11, 1),
(12, 'Sexto', 'B', 12, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `examen`
--

CREATE TABLE `examen` (
  `idExamen` int(11) NOT NULL,
  `fecha` datetime DEFAULT NULL,
  `nota` decimal(2,0) DEFAULT NULL,
  `Asignatura_has_Curso_has_Alumno_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idCurso` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `examen`
--

INSERT INTO `examen` (`idExamen`, `fecha`, `nota`, `Asignatura_has_Curso_has_Alumno_idAsignatura`, `Asignatura_has_Curso_has_Alumno_idCurso`, `Asignatura_has_Curso_has_Alumno_idAlumno`) VALUES
(1, '2016-12-08 18:57:59', '5', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `expediente`
--

CREATE TABLE `expediente` (
  `numExpediente` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `expediente`
--

INSERT INTO `expediente` (`numExpediente`) VALUES
(1),
(2),
(3),
(4),
(5),
(6),
(7),
(8),
(9),
(10),
(11),
(12),
(13),
(14),
(15);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `foro`
--

CREATE TABLE `foro` (
  `idForo` int(11) NOT NULL,
  `tema` varchar(45) NOT NULL,
  `Asignatura_has_Curso_Asignatura_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_Curso_idCurso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `foro`
--

INSERT INTO `foro` (`idForo`, `tema`, `Asignatura_has_Curso_Asignatura_idAsignatura`, `Asignatura_has_Curso_Curso_idCurso`) VALUES
(1, 'Los ecosistemas', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `material`
--

CREATE TABLE `material` (
  `idmaterial` int(11) NOT NULL,
  `contenido` longblob NOT NULL,
  `asignatura_has_curso_Asignatura_idAsignatura` int(11) NOT NULL,
  `asignatura_has_curso_Curso_idCurso` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mencion`
--

CREATE TABLE `mencion` (
  `idMenciones` int(11) NOT NULL,
  `titulo` varchar(45) DEFAULT NULL,
  `descripcion` longtext,
  `idAsignatura` int(11) NOT NULL,
  `idCurso` int(11) NOT NULL,
  `idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `mencion`
--

INSERT INTO `mencion` (`idMenciones`, `titulo`, `descripcion`, `idAsignatura`, `idCurso`, `idAlumno`) VALUES
(1, 'Premio por excelecia', 'por su sobresaliente labor en el campo de la excelencia', 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mensaje`
--

CREATE TABLE `mensaje` (
  `idmensaje` int(11) NOT NULL,
  `texto` longtext NOT NULL,
  `fecha` datetime NOT NULL,
  `chat_Profesor_idProfesor` int(11) NOT NULL,
  `chat_Padre_Alumno_idAlumno` int(11) NOT NULL,
  `profesor` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `padre`
--

CREATE TABLE `padre` (
  `idPadre` int(11) DEFAULT NULL,
  `nombre` varchar(45) DEFAULT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `password` varchar(45) NOT NULL,
  `user` varchar(45) NOT NULL,
  `Alumno_idAlumno` int(11) NOT NULL,
  `dni` varchar(20) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `telefono` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `padre`
--

INSERT INTO `padre` (`idPadre`, `nombre`, `apellidos`, `password`, `user`, `Alumno_idAlumno`, `dni`, `email`, `telefono`) VALUES
(1, 'Rodolfo', 'Summers', '1234', 'rudolf', 1, '45825463T', 'lejia@neutrex.com', 654654654),
(2, 'Auxiliadora', 'Valderrama Mendoza', '1234', 'gastroentiritis', 2, '12312312A', 'lagastro@hotmail.com', 555555555),
(2, 'Auxiliadora', 'Valderrama Mendoza', '1234', 'gastroentiritis', 3, '12312312A', 'lagastro@hotmail.com', 555555555);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE `profesor` (
  `idProfesor` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `dni` varchar(45) NOT NULL,
  `telefono` int(11) DEFAULT NULL,
  `user` varchar(45) CHARACTER SET utf8 COLLATE utf8_spanish2_ci NOT NULL,
  `password` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`idProfesor`, `nombre`, `apellidos`, `email`, `dni`, `telefono`, `user`, `password`) VALUES
(1, 'Diego', 'Mendoza', 'dm1@alu.ua.es', '4545647P', 666666666, '', ''),
(2, 'Bernardo', 'Galipienso', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(3, 'Luisa', 'Ramos', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(4, 'Juan', 'Salazar', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(5, 'Angustias', 'López', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(6, 'Josefa', 'Saramago', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(7, 'Guillermo', 'Mata', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(8, 'Carmen', 'San Diego', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(9, 'Matilde', 'Salvador i Segarra', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(10, 'Antonio', 'García Cayuelas', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(11, 'Olegario', 'Do Marco Seller', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(12, 'Margarita', 'Sastre', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(13, 'Miguel', 'Serrano', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(14, 'Santiago', 'Colomar', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(15, 'Pep', 'Llorens', 'bg2@alu.ua.es', '85285285J', 666666666, '', ''),
(16, 'Calígula', 'Cantalejo Molina', 'calican@hoi.com', '88888888R', 966666666, 'elcali23', '1234');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tarea`
--

CREATE TABLE `tarea` (
  `idTareas` int(11) NOT NULL,
  `descripcion` varchar(45) NOT NULL,
  `fecha_limite` datetime DEFAULT NULL,
  `completada` tinyint(1) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAsignatura` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idCurso` int(11) NOT NULL,
  `Asignatura_has_Curso_has_Alumno_idAlumno` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tarea`
--

INSERT INTO `tarea` (`idTareas`, `descripcion`, `fecha_limite`, `completada`, `Asignatura_has_Curso_has_Alumno_idAsignatura`, `Asignatura_has_Curso_has_Alumno_idCurso`, `Asignatura_has_Curso_has_Alumno_idAlumno`) VALUES
(1, 'Describir el ecosistema del gusano de seda', '2016-12-08 23:20:56', 0, 1, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipocentro`
--

CREATE TABLE `tipocentro` (
  `tipo` varchar(45) NOT NULL,
  `descripcion` varchar(25) CHARACTER SET utf8 COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Volcado de datos para la tabla `tipocentro`
--

INSERT INTO `tipocentro` (`tipo`, `descripcion`) VALUES
('1', 'Colegio privado'),
('2', 'Academia');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administrador`
--
ALTER TABLE `administrador`
  ADD PRIMARY KEY (`idAdministrador`),
  ADD UNIQUE KEY `user_UNIQUE` (`user`),
  ADD UNIQUE KEY `idAdministrador_UNIQUE` (`idAdministrador`);

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD PRIMARY KEY (`idAlumno`),
  ADD KEY `fk_Alumno_InformeAlumno1_idx` (`InformeAlumno_numExpediente`);

--
-- Indices de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  ADD PRIMARY KEY (`idAsignatura`),
  ADD UNIQUE KEY `nombre_UNIQUE` (`nombre`);

--
-- Indices de la tabla `asignatura_has_curso`
--
ALTER TABLE `asignatura_has_curso`
  ADD PRIMARY KEY (`Asignatura_idAsignatura`,`Curso_idCurso`),
  ADD KEY `fk_Asignatura_has_Curso_Curso1_idx` (`Curso_idCurso`),
  ADD KEY `fk_Asignatura_has_Curso_Asignatura1_idx` (`Asignatura_idAsignatura`),
  ADD KEY `fk_Asignatura_has_Curso_Profesor1_idx` (`Profesor_idProfesor`);

--
-- Indices de la tabla `asignatura_has_curso_has_alumno`
--
ALTER TABLE `asignatura_has_curso_has_alumno`
  ADD PRIMARY KEY (`idAsignatura`,`idCurso`,`idAlumno`),
  ADD KEY `fk_Asignatura_has_Curso_has_Alumno_Alumno1_idx` (`idAlumno`),
  ADD KEY `fk_Asignatura_has_Curso_has_Alumno_Asignatura_has_Curso1_idx` (`idAsignatura`,`idCurso`);

--
-- Indices de la tabla `asistencia`
--
ALTER TABLE `asistencia`
  ADD PRIMARY KEY (`idAsistencia`,`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`),
  ADD KEY `fk_Asistencia_Asignatura_has_Curso_has_Alumno1_idx` (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`);

--
-- Indices de la tabla `centro`
--
ALTER TABLE `centro`
  ADD PRIMARY KEY (`idCentro`),
  ADD KEY `fk_Centro_TipoCentro_idx` (`TipoCentro_tipo`),
  ADD KEY `fk_Centro_Administrador1_idx` (`Administrador_idAdministrador`);

--
-- Indices de la tabla `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`Profesor_idProfesor`,`Padre_Alumno_idAlumno`),
  ADD KEY `fk_Padre_has_Profesor_Profesor1_idx` (`Profesor_idProfesor`),
  ADD KEY `fk_Chat_Padre1_idx` (`Padre_Alumno_idAlumno`);

--
-- Indices de la tabla `comentarios_sobre_el_alumno`
--
ALTER TABLE `comentarios_sobre_el_alumno`
  ADD PRIMARY KEY (`idComentarios_sobre_el_alumno`,`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`),
  ADD KEY `fk_Comentarios_sobre_el_alumno_Asignatura_has_Curso_has_Alu_idx` (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`);

--
-- Indices de la tabla `comentario_alumno`
--
ALTER TABLE `comentario_alumno`
  ADD PRIMARY KEY (`idComentario`,`Foro_idForo`,`Alumno_idAlumno`),
  ADD KEY `fk_Comentario_Foro1_idx` (`Foro_idForo`),
  ADD KEY `fk_Comentario_alumno_Alumno1_idx` (`Alumno_idAlumno`);

--
-- Indices de la tabla `comentario_profesor`
--
ALTER TABLE `comentario_profesor`
  ADD PRIMARY KEY (`idComentario`,`Foro_idForo`,`Profesor_idProfesor`),
  ADD KEY `fk_Comentario_Foro1_idx` (`Foro_idForo`),
  ADD KEY `fk_Comentario_profesor_Profesor1_idx` (`Profesor_idProfesor`);

--
-- Indices de la tabla `comunicado`
--
ALTER TABLE `comunicado`
  ADD PRIMARY KEY (`idcomunicado`,`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`),
  ADD KEY `fk_Comunicado_Asignatura_has_Curso1_idx` (`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`),
  ADD KEY `fk_Comunicado_Alumno1_idx` (`Alumno_idAlumno`);

--
-- Indices de la tabla `curso`
--
ALTER TABLE `curso`
  ADD PRIMARY KEY (`idCurso`,`centro_idCentro`),
  ADD KEY `fk_Curso_Profesor1_idx` (`Profesor_idProfesor`),
  ADD KEY `fk_curso_centro1_idx` (`centro_idCentro`);

--
-- Indices de la tabla `examen`
--
ALTER TABLE `examen`
  ADD PRIMARY KEY (`idExamen`,`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`),
  ADD KEY `fk_Examen_Asignatura_has_Curso_has_Alumno1_idx` (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`);

--
-- Indices de la tabla `expediente`
--
ALTER TABLE `expediente`
  ADD PRIMARY KEY (`numExpediente`);

--
-- Indices de la tabla `foro`
--
ALTER TABLE `foro`
  ADD PRIMARY KEY (`idForo`,`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`),
  ADD KEY `fk_Foro_Asignatura_has_Curso1_idx` (`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`);

--
-- Indices de la tabla `material`
--
ALTER TABLE `material`
  ADD PRIMARY KEY (`idmaterial`,`asignatura_has_curso_Asignatura_idAsignatura`,`asignatura_has_curso_Curso_idCurso`),
  ADD KEY `fk_material_asignatura_has_curso1_idx` (`asignatura_has_curso_Asignatura_idAsignatura`,`asignatura_has_curso_Curso_idCurso`);

--
-- Indices de la tabla `mencion`
--
ALTER TABLE `mencion`
  ADD PRIMARY KEY (`idMenciones`),
  ADD KEY `fk_Mencion_Asignatura_has_Curso_has_Alumno1_idx` (`idAsignatura`,`idCurso`,`idAlumno`);

--
-- Indices de la tabla `mensaje`
--
ALTER TABLE `mensaje`
  ADD PRIMARY KEY (`idmensaje`,`chat_Profesor_idProfesor`,`chat_Padre_Alumno_idAlumno`),
  ADD KEY `fk_mensaje_profesor_chat1_idx` (`chat_Profesor_idProfesor`,`chat_Padre_Alumno_idAlumno`);

--
-- Indices de la tabla `padre`
--
ALTER TABLE `padre`
  ADD PRIMARY KEY (`Alumno_idAlumno`);

--
-- Indices de la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD PRIMARY KEY (`idProfesor`);

--
-- Indices de la tabla `tarea`
--
ALTER TABLE `tarea`
  ADD PRIMARY KEY (`idTareas`),
  ADD KEY `fk_Tarea_Asignatura_Curso_Alumno1_idx` (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`);

--
-- Indices de la tabla `tipocentro`
--
ALTER TABLE `tipocentro`
  ADD PRIMARY KEY (`tipo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administrador`
--
ALTER TABLE `administrador`
  MODIFY `idAdministrador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT de la tabla `asignatura`
--
ALTER TABLE `asignatura`
  MODIFY `idAsignatura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT de la tabla `centro`
--
ALTER TABLE `centro`
  MODIFY `idCentro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT de la tabla `comentarios_sobre_el_alumno`
--
ALTER TABLE `comentarios_sobre_el_alumno`
  MODIFY `idComentarios_sobre_el_alumno` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `comentario_alumno`
--
ALTER TABLE `comentario_alumno`
  MODIFY `idComentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `comentario_profesor`
--
ALTER TABLE `comentario_profesor`
  MODIFY `idComentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `comunicado`
--
ALTER TABLE `comunicado`
  MODIFY `idcomunicado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT de la tabla `curso`
--
ALTER TABLE `curso`
  MODIFY `idCurso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT de la tabla `foro`
--
ALTER TABLE `foro`
  MODIFY `idForo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno`
--
ALTER TABLE `alumno`
  ADD CONSTRAINT `fk_Alumno_InformeAlumno1` FOREIGN KEY (`InformeAlumno_numExpediente`) REFERENCES `expediente` (`numExpediente`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asignatura_has_curso`
--
ALTER TABLE `asignatura_has_curso`
  ADD CONSTRAINT `fk_Asignatura_has_Curso_Asignatura1` FOREIGN KEY (`Asignatura_idAsignatura`) REFERENCES `asignatura` (`idAsignatura`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Asignatura_has_Curso_Curso1` FOREIGN KEY (`Curso_idCurso`) REFERENCES `curso` (`idCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Asignatura_has_Curso_Profesor1` FOREIGN KEY (`Profesor_idProfesor`) REFERENCES `profesor` (`idProfesor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asignatura_has_curso_has_alumno`
--
ALTER TABLE `asignatura_has_curso_has_alumno`
  ADD CONSTRAINT `fk_Asignatura_has_Curso_has_Alumno_Alumno1` FOREIGN KEY (`idAlumno`) REFERENCES `alumno` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Asignatura_has_Curso_has_Alumno_Asignatura_has_Curso1` FOREIGN KEY (`idAsignatura`,`idCurso`) REFERENCES `asignatura_has_curso` (`Asignatura_idAsignatura`, `Curso_idCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `asistencia`
--
ALTER TABLE `asistencia`
  ADD CONSTRAINT `fk_Asistencia_Asignatura_has_Curso_has_Alumno1` FOREIGN KEY (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`) REFERENCES `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `centro`
--
ALTER TABLE `centro`
  ADD CONSTRAINT `fk_Centro_Administrador1` FOREIGN KEY (`Administrador_idAdministrador`) REFERENCES `administrador` (`idAdministrador`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Centro_TipoCentro` FOREIGN KEY (`TipoCentro_tipo`) REFERENCES `tipocentro` (`tipo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `chat`
--
ALTER TABLE `chat`
  ADD CONSTRAINT `fk_Chat_Padre1` FOREIGN KEY (`Padre_Alumno_idAlumno`) REFERENCES `padre` (`Alumno_idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Padre_has_Profesor_Profesor1` FOREIGN KEY (`Profesor_idProfesor`) REFERENCES `profesor` (`idProfesor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comentarios_sobre_el_alumno`
--
ALTER TABLE `comentarios_sobre_el_alumno`
  ADD CONSTRAINT `fk_Comentarios_sobre_el_alumno_Asignatura_has_Curso_has_Alumno1` FOREIGN KEY (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`) REFERENCES `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comentario_alumno`
--
ALTER TABLE `comentario_alumno`
  ADD CONSTRAINT `fk_Comentario_Foro1` FOREIGN KEY (`Foro_idForo`) REFERENCES `foro` (`idForo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Comentario_alumno_Alumno1` FOREIGN KEY (`Alumno_idAlumno`) REFERENCES `alumno` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comentario_profesor`
--
ALTER TABLE `comentario_profesor`
  ADD CONSTRAINT `fk_Comentario_Foro10` FOREIGN KEY (`Foro_idForo`) REFERENCES `foro` (`idForo`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Comentario_profesor_Profesor1` FOREIGN KEY (`Profesor_idProfesor`) REFERENCES `profesor` (`idProfesor`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `comunicado`
--
ALTER TABLE `comunicado`
  ADD CONSTRAINT `fk_Comunicado_Alumno1` FOREIGN KEY (`Alumno_idAlumno`) REFERENCES `alumno` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_Comunicado_Asignatura_has_Curso1` FOREIGN KEY (`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`) REFERENCES `asignatura_has_curso` (`Asignatura_idAsignatura`, `Curso_idCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `curso`
--
ALTER TABLE `curso`
  ADD CONSTRAINT `fk_Curso_Profesor1` FOREIGN KEY (`Profesor_idProfesor`) REFERENCES `profesor` (`idProfesor`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curso_centro1` FOREIGN KEY (`centro_idCentro`) REFERENCES `centro` (`idCentro`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `examen`
--
ALTER TABLE `examen`
  ADD CONSTRAINT `fk_Examen_Asignatura_has_Curso_has_Alumno1` FOREIGN KEY (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`) REFERENCES `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `foro`
--
ALTER TABLE `foro`
  ADD CONSTRAINT `fk_Foro_Asignatura_has_Curso1` FOREIGN KEY (`Asignatura_has_Curso_Asignatura_idAsignatura`,`Asignatura_has_Curso_Curso_idCurso`) REFERENCES `asignatura_has_curso` (`Asignatura_idAsignatura`, `Curso_idCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `material`
--
ALTER TABLE `material`
  ADD CONSTRAINT `fk_material_asignatura_has_curso1` FOREIGN KEY (`asignatura_has_curso_Asignatura_idAsignatura`,`asignatura_has_curso_Curso_idCurso`) REFERENCES `asignatura_has_curso` (`Asignatura_idAsignatura`, `Curso_idCurso`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `mencion`
--
ALTER TABLE `mencion`
  ADD CONSTRAINT `fk_Mencion_Asignatura_has_Curso_has_Alumno1` FOREIGN KEY (`idAsignatura`,`idCurso`,`idAlumno`) REFERENCES `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `mensaje`
--
ALTER TABLE `mensaje`
  ADD CONSTRAINT `fk_mensaje_profesor_chat1` FOREIGN KEY (`chat_Profesor_idProfesor`,`chat_Padre_Alumno_idAlumno`) REFERENCES `chat` (`Profesor_idProfesor`, `Padre_Alumno_idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `padre`
--
ALTER TABLE `padre`
  ADD CONSTRAINT `fk_Padre_Alumno1` FOREIGN KEY (`Alumno_idAlumno`) REFERENCES `alumno` (`idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tarea`
--
ALTER TABLE `tarea`
  ADD CONSTRAINT `fk_Tarea_Asignatura_Curso_Alumno1` FOREIGN KEY (`Asignatura_has_Curso_has_Alumno_idAsignatura`,`Asignatura_has_Curso_has_Alumno_idCurso`,`Asignatura_has_Curso_has_Alumno_idAlumno`) REFERENCES `asignatura_has_curso_has_alumno` (`idAsignatura`, `idCurso`, `idAlumno`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
