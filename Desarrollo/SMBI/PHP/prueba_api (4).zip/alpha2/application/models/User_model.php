<?php
class Asignatura_has_curso_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_asignatura_has_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('asignatura_has_curso_has_curso', array('tipo' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('asignatura', array('idAsignatura' => $id));
		        return $query->row_array();
		}
		public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $id));
		        return $query->row_array();
		}

		public function get_profesor($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('profesor', array('idProfesor' => $id));
		        return $query->row_array();
		}

		public function post_asignatura_has_curso($asignatura_has_curso)
		{
		        $this->db->set( $this->_setasignatura_has_curso($asignatura_has_curso) )->insert("asignatura_has_curso");

		        if($this->db->affected_rows()===1)
		        {
		        	return TRUE;
		        }

		        return NULL;
		}

		public function _setAsignatura_has_curso($asignatura_has_curso)
		{
			$data1 = array(

		        'idasignatura_has_curso' => $asignatura_has_curso["idasignatura_has_curso"],
		        'nombre' => $asignatura_has_curso["nombre"],
		        'direccion' => $asignatura_has_curso["direccion"],
		        'Tipoasignatura_has_curso_tipo' => $asignatura_has_curso["Tipoasignatura_has_curso_tipo"],
		        'Administrador_idAdministrador' => $asignatura_has_curso["Administrador_idAdministrador"],
		        'password' => $asignatura_has_curso["password"],
		        'telefono' => $asignatura_has_curso["telefono"],
		        'dni' => $asignatura_has_curso["dni"]
	        
	        );

	        return $data1;
		}


}


?>