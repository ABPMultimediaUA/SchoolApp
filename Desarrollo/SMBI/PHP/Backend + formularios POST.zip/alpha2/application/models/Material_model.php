<?php
class Material_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_idmaterial($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('material', array('idMaterial' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('Asignatura_has_Curso', array('Asignatura_idAsignatura' => $id));
		        return $query->row_array();
		}
		public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('Asignatura_has_Curso', array('Curso_idCurso' => $id));
		        return $query->row_array();
		}

		

		public function post_material($material)
		{
		        $res=$this->db->set( $this->_setmaterial($material) )->insert("material");
		        return $res;
		}

		public function _setmaterial($material)
		{
			$data1 = array(

		        
		        'asignatura_has_curso_Curso_idCurso' => $material["asignatura_has_curso_Curso_idCurso"],
		        'asignatura_has_curso_Asignatura_idAsignatura' => $material["asignatura_has_curso_Asignatura_idAsignatura"],
		        'contenido' => $material["contenido"]
	        );

	        return $data1;
		}


}


?>