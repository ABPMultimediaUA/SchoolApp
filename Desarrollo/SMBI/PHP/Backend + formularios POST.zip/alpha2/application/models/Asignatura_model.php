<?php
class Asignatura_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $id));
		        return $query->row_array();
		}

		public function get_idAsignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('asignatura', array('idAsignatura' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                $query = $this->db->get('asignatura');
		                return $query->result_array();
		        }

		        $query = $this->db->get_where('asignatura', array('idasignatura' => $id));
		        return $query->row_array();
		}

		public function post_asignatura($asignatura)
		{
		        $res = $this->db->set( $this->_setAsignatura($asignatura) )->insert("asignatura");

		        

		        return $res;
		}

		public function _setAsignatura($asignatura)
		{
			$data1 = array(

		        'idAsignatura' => $asignatura["idAsignatura"],
		        'nombre' => $asignatura["nombre"],
		        'curso' => $asignatura["curso"]
	        
	        );

	        return $data1;
		}


}


?>