<?php
class Foro_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_idForo($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('foro', array('idForo' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('asignatura', array('idAsignatura' => $id));
		        return $query->row_array();
		}
		public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $id));
		        return $query->row_array();
		}

		

		public function post_foro($foro)
		{
		        $res=$this->db->set( $this->_setforo($foro) )->insert("foro");
		        return $res;
		}

		public function _setforo($foro)
		{
			$data1 = array(

		        'tema' => $foro["tema"],
		        'Asignatura_has_Curso_Asignatura_idAsignatura' => $foro["Asignatura_has_Curso_Asignatura_idAsignatura"],
		        'Asignatura_has_Curso_Curso_idCurso' => $foro["Asignatura_has_Curso_Curso_idCurso"]
	        
	        );

	        return $data1;
		}


}


?>