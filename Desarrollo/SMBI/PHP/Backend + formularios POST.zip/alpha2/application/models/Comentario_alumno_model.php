<?php
class Comentario_alumno_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_idcomentario_alumno($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('comentario_alumno', array('idComentario' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('asignatura', array('idAsignatura' => $id));
		        return $query->row_array();
		}
		public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $id));
		        return $query->row_array();
		}

		

		public function post_comentario_alumno($comentario_alumno)
		{
		        $res=$this->db->set( $this->_setcomentario_alumno($comentario_alumno) )->insert("comentario_alumno");
		        return $res;
		}

		public function _setcomentario_alumno($comentario_alumno)
		{
			$data1 = array(

		        'Foro_idForo' => $comentario_alumno["Foro_idForo"],
		        'texto' => $comentario_alumno["texto"],
		        'fecha' => $comentario_alumno["fecha"],
		        'Alumno_idAlumno' => $comentario_alumno["Alumno_idAlumno"]
	        );

	        return $data1;
		}


}


?>