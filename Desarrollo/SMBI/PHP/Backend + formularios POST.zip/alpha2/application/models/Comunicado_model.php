<?php
class Comunicado_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }


        public function get_idcomunicado($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		               return "";
		        }

		        $query = $this->db->get_where('comunicado', array('idComunicado' => $id));
		        return $query->row_array();
		}


		public function get_asignatura($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('asignatura', array('idAsignatura' => $id));
		        return $query->row_array();
		}
		public function get_curso($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $id));
		        return $query->row_array();
		}

		

		public function post_comunicado($comunicado)
		{
		        $res=$this->db->set( $this->_setcomunicado($comunicado) )->insert("comunicado");
		        return $res;
		      
		}

		public function _setcomunicado($comunicado)
		{
			$data1 = array(
		        'Asignatura_has_Curso_Curso_idCurso' => $comunicado["Asignatura_has_Curso_Curso_idCurso"],
		        'Asignatura_has_Curso_Asignatura_idAsignatura' => $comunicado["Asignatura_has_Curso_Asignatura_idAsignatura"],
		        'texto' => $comunicado["texto"],
		        'tipo' => $comunicado["tipo"],
		        'firmado' => $comunicado["firmado"],
		        'fecha' => $comunicado["fecha"],
		        'Alumno_idAlumno' => $comunicado["Alumno_idAlumno"]
	        );

	        return $data1;
		}


}


?>