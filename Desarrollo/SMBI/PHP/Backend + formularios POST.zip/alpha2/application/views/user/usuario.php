<?php
echo '<h2>'.$user_item['nombre']." ".$user_item['apellidos'].'</h2>';
echo '<p>'.$user_item['email'].'</p>';
echo '<p>'.$user_item['user'].'</p>';
echo '<p>'.$user_item['idAlumno'].'</p>';
/*$miArray = array("nombre"=>$user_item['nombre']." ".$user_item['apellidos'], "email"=>$user_item['email'], "usuario"=>$user_item['user'], "id"=>$user_item['idAlumno']);
                $objeto=json_encode($miArray);
                print_r($objeto);?>*/