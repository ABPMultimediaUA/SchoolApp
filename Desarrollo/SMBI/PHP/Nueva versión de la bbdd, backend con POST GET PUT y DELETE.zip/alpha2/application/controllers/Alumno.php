<?php

defined('BASEPATH') OR exit('No direct script access allowed');

// This can be removed if you use __autoload() in config.php OR use Modular Extensions
/** @noinspection PhpIncludeInspection */
require APPPATH . '/libraries/REST_Controller.php';

// use namespace
use Restserver\Libraries\REST_Controller;

/**
 * This is an example of a few basic alumno interaction methods you could use
 * all done with a hardcoded array
 *
 * @package         CodeIgniter
 * @subpackage      Rest Server
 * @category        Controller
 * @author          Phil Sturgeon, Chris Kacerguis
 * @license         MIT
 * @link            https://github.com/chriskacerguis/codeigniter-restserver
 */
class Alumno extends REST_Controller {

    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        $this->load->database();
        $this->load->model('alumno_model');
        $this->load->helper('url_helper');

        // Configure limits on our controller methods
        // Ensure you have created the 'limits' table and enabled 'limits' within application/config/rest.php
        $this->methods['alumno_get']['limit'] = 500; // 500 requests per hour per alumno/key
        $this->methods['alumno_post']['limit'] = 100; // 100 requests per hour per alumno/key
        $this->methods['alumno_delete']['limit'] = 50; // 50 requests per hour per alumno/key
    }

    public function alumno_get()
    {
    


        $id = $this->get('id');



        // If the id parameter doesn't exist return all the alumno

        if ($id === NULL)
        {

            
            $alumno = $this->alumno_model->get_alumno();

            // Check if the alumno data store contains alumno (in case the database result returns NULL)
            if ($alumno)
            {
                // Set the response and exit
                $this->response($alumno, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {
                // Set the response and exit
                $this->response([
                    'status' => FALSE,
                    'message' => 'No alumno were found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }

        // Find and return a single record for a particular alumno.
        else {
            $id = (int) $id;

            // Validate the id.
            if ($id <= 0)
            {
                // Invalid id, set the response and exit.
                $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
            }

            // Get the alumno from the array, using the id as key for retrieval.
            // Usually a model is to be used for this.

            $alumno = $this->alumno_model->get_alumno($id);

            if (!empty($alumno))
            {
                foreach ($alumno as $key => $value)
                {
                    if (isset($value['idAlumno']) && $value['idAlumno'] === $id)
                    {
                        $alumno = $value;
                    }
                }
            }

            if (!empty($alumno))
            {   $alumno[0]=$alumno;
                $this->set_response($alumno, REST_Controller::HTTP_OK); // OK (200) being the HTTP response code
            }
            else
            {
                $this->set_response([
                    'status' => FALSE,
                    'message' => 'alumno could not be found'
                ], REST_Controller::HTTP_NOT_FOUND); // NOT_FOUND (404) being the HTTP response code
            }
        }
    }

   

    public function alumno_post()
    {
        $numExp = $this->alumno_model->get_expediente($this->post('InformeAlumno_numExpediente'));
        $idCurso = $this->alumno_model->get_curso($this->post('curso_idCurso'));
        $idCentro = $this->alumno_model->get_centro($this->post('curso_centro_idCentro'));
        $idAlumno = $this->alumno_model->get_idAlumno($this->post('idAlumno'));
        $respuestaError=[];

        if($numExp == "")
            {
                array_push($respuestaError,"El numero de expediente indicado no existe. ");
            }

        if($idCurso == "")
            {
                array_push($respuestaError,"El numero de ID de Curso indicado no existe. ");
            }

        if($idCentro == "")
            {
                array_push($respuestaError,"El numero de ID de Centro indicado no existe. ");
            }
        if($idAlumno != "")
        {
            array_push($respuestaError, "El numero de ID del alumno indicado ya existe");
        }

        if(count($respuestaError)>=1)
            {
                    $this->output->set_output(json_encode($respuestaError), REST_Controller::HTTP_BAD_REQUEST); 
            }
            else
            {
             

                $this->alumno_model->post_alumno($this->post());

                $this->output->set_output("Alumno added to database", REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
            }
    }

    public function alumno_put()
    {
                $res = $this->alumno_model->put_alumno($this->put());

                $this->output->set_output($res, REST_Controller::HTTP_CREATED); // CREATED (201) being the HTTP response code
            
    }

    public function alumno_delete()
    {
        $id = (int) $this->get('id');

        // Validate the id.
        if ($id <= 0)
        {
            // Set the response and exit
            $this->response(NULL, REST_Controller::HTTP_BAD_REQUEST); // BAD_REQUEST (400) being the HTTP response code
        }

        
        $message =  $this->alumno_model->delete_alumno($id);

        if($message!=1 && $message!=true)
        $this->set_response($message, REST_Controller::HTTP_BAD_REQUEST); // NO_CONTENT (204) being the HTTP response code
        else
           $this->set_response($message, REST_Controller::HTTP_OK); 
    }



}
