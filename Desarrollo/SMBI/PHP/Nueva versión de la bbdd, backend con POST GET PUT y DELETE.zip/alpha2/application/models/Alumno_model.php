<?php
class Alumno_model extends CI_Model {



        public function __construct()
        {
                $this->load->database();
        }

        public function get_idAlumno($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                return "";
		        }

		        $query = $this->db->get_where('alumno', array('idAlumno' => $id));
		        return $query->row_array();
		}

		public function get_alumno($id = FALSE)
		{
		        if ($id === FALSE)
		        {
		                $query = $this->db->get('alumno');
		                return $query->result_array();
		        }

		        $query = $this->db->get_where('alumno', array('idAlumno' => $id));
		        return $query->row_array();
		}

		public function get_alumnoByNombre($nombre = FALSE, $apellidos = FALSE)
		{
		        if ($nombre === FALSE || $apellidos = FALSE)
		        {
		                $query = $this->db->get('alumno');
		                return $query->result_array();
		        }

		        $query = $this->db->get_where('alumno', array('nombre' => $nombre));
		        $arquery= $query->row_array();
		        $size = count($arquery);
		        $res = [];
		        for($i=0;$i<$size;$i++)
		        {
		        	if($arquery[$i]["apellidos"]==$apellidos)
		        	{
		        		array_push($res, $arquery[$i]);
		        	}
		        }
		        return $res;
		}

		public function get_expediente($exp = FALSE)
		{
		        if ($exp === FALSE)
		        {
		                
		                return "";
		        }

		        $query = $this->db->get_where('expediente', array('numExpediente' => $exp));
		        return $query->row_array();
		}

		public function get_curso($cur = FALSE)
		{
		        if ($cur === FALSE)
		        {
		                
		                return "";
		        }

		        $query = $this->db->get_where('curso', array('idCurso' => $cur));
		        return $query->row_array();
		}

		public function get_centro($cen = FALSE)
		{
		        if ($cen === FALSE)
		        {
		                
		                return "";
		        }

		        $query = $this->db->get_where('centro', array('idCentro' => $cen));
		        return $query->row_array();
		}

		public function post_alumno($alumno)
		{
		        $this->db->set( $this->_setalumno($alumno) )->insert("alumno");

		        if($this->db->affected_rows()===1)
		        {
		        	return TRUE;
		        }

		        return NULL;
		}

		public function put_alumno($data)
		{
		       
				$alumno = $this->_setalumno($data);
				$this->db->where('idAlumno', $data['idAlumno']);
				$res = $this->db->update('alumno', $data);
				return $res;
		}

		public function delete_alumno($id)
		{
		        $res=$this->db->delete('alumno', array('idAlumno' => $id));
		        return $res;
		}

		public function _setalumno($alumno)
		{
			$data1 = array(

		        'idAlumno' => $alumno["idAlumno"],
		        'nombre' => $alumno["nombre"],
		        'email' => $alumno["email"],
		        'apellidos' => $alumno["apellidos"],
		        'user' => $alumno["user"],
		        'password' => $alumno["password"],
		        'telefono' => $alumno["telefono"],
		        'dni' => $alumno["dni"],
		        'InformeAlumno_numExpediente' => $alumno["InformeAlumno_numExpediente"],
		        'curso_idCurso' => $alumno["curso_idCurso"],
		        'curso_centro_idCentro' => $alumno["curso_centro_idCentro"]
	        
	        );

	        return $data1;
		}


}


?>